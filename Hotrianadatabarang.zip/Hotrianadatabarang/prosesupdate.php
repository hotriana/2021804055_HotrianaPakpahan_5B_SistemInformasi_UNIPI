<?php
// koneksi database
include 'koneksi.php';
//Memproses data saat form di submit
if(isset($_POST["kode barang"]) && !empty($_POST["kode barang"])){
// menangkap data yang di kirim dari form
$kode = $_POST['kode barang'];
$nama = $_POST['nama barang'];
$satuan = $_POST['satuan'];
$kategori = $_POST['kategori'];
$hrgmodal = $_POST['harga modal'];
$hrgjual = $_POST['harga jual'];
$namafile = $_POST['photo'];
// mengupdate data ke database
$update=mysqli_query($koneksi,"UPDATE dbbarang SET
nama barang='$nama',satuan='$satuan',kategori='$kategori',harga modal='$hrgmodal',harga jual='$hrgjual',photo='$namafile'
WHERE kode barang='$kode'")or die(mysql_error());
if($update){
header("location:index.php");
}else{
echo'Gagal menyimpan data! ';
echo'<a href="index.php">Kembali</a>';
}
}
?>